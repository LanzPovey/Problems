﻿namespace _5thUnit05Question1
{
    partial class frmBathroomTile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBathroomTile));
            this.tlsColorPatterns = new System.Windows.Forms.ToolStrip();
            this.cmbColor = new System.Windows.Forms.ToolStripComboBox();
            this.sepColor = new System.Windows.Forms.ToolStripSeparator();
            this.lblTile = new System.Windows.Forms.ToolStripLabel();
            this.txbTile = new System.Windows.Forms.ToolStripTextBox();
            this.sepTile = new System.Windows.Forms.ToolStripSeparator();
            this.btnRectanglePattern = new System.Windows.Forms.ToolStripButton();
            this.lblRectanglePattern = new System.Windows.Forms.ToolStripLabel();
            this.btnTriangleButton = new System.Windows.Forms.ToolStripButton();
            this.lblTrianglePattern = new System.Windows.Forms.ToolStripLabel();
            this.cdbColor = new System.Windows.Forms.ColorDialog();
            this.tlsColorPatterns.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlsColorPatterns
            // 
            this.tlsColorPatterns.BackColor = System.Drawing.Color.PaleGreen;
            this.tlsColorPatterns.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmbColor,
            this.sepColor,
            this.lblTile,
            this.txbTile,
            this.sepTile,
            this.btnRectanglePattern,
            this.lblRectanglePattern,
            this.btnTriangleButton,
            this.lblTrianglePattern});
            this.tlsColorPatterns.Location = new System.Drawing.Point(0, 0);
            this.tlsColorPatterns.Name = "tlsColorPatterns";
            this.tlsColorPatterns.Size = new System.Drawing.Size(932, 25);
            this.tlsColorPatterns.TabIndex = 3;
            // 
            // cmbColor
            // 
            this.cmbColor.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.cmbColor.Name = "cmbColor";
            this.cmbColor.Size = new System.Drawing.Size(121, 25);
            // 
            // sepColor
            // 
            this.sepColor.Name = "sepColor";
            this.sepColor.Size = new System.Drawing.Size(6, 25);
            // 
            // lblTile
            // 
            this.lblTile.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.lblTile.Name = "lblTile";
            this.lblTile.Size = new System.Drawing.Size(71, 22);
            this.lblTile.Text = "Set Tile Size:";
            // 
            // txbTile
            // 
            this.txbTile.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.txbTile.ForeColor = System.Drawing.Color.ForestGreen;
            this.txbTile.Name = "txbTile";
            this.txbTile.Size = new System.Drawing.Size(100, 25);
            // 
            // sepTile
            // 
            this.sepTile.Name = "sepTile";
            this.sepTile.Size = new System.Drawing.Size(6, 25);
            // 
            // btnRectanglePattern
            // 
            this.btnRectanglePattern.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnRectanglePattern.Image = ((System.Drawing.Image)(resources.GetObject("btnRectanglePattern.Image")));
            this.btnRectanglePattern.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRectanglePattern.Name = "btnRectanglePattern";
            this.btnRectanglePattern.Size = new System.Drawing.Size(23, 22);
            this.btnRectanglePattern.Text = "toolStripButton1";
            this.btnRectanglePattern.Click += new System.EventHandler(this.btnRectanglePattern_Click);
            // 
            // lblRectanglePattern
            // 
            this.lblRectanglePattern.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.lblRectanglePattern.Name = "lblRectanglePattern";
            this.lblRectanglePattern.Size = new System.Drawing.Size(100, 22);
            this.lblRectanglePattern.Text = "Rectangle Pattern";
            // 
            // btnTriangleButton
            // 
            this.btnTriangleButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnTriangleButton.Image = ((System.Drawing.Image)(resources.GetObject("btnTriangleButton.Image")));
            this.btnTriangleButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTriangleButton.Name = "btnTriangleButton";
            this.btnTriangleButton.Size = new System.Drawing.Size(23, 22);
            this.btnTriangleButton.Text = "toolStripButton2";
            this.btnTriangleButton.Click += new System.EventHandler(this.btnTriangleButton_Click);
            // 
            // lblTrianglePattern
            // 
            this.lblTrianglePattern.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.lblTrianglePattern.Name = "lblTrianglePattern";
            this.lblTrianglePattern.Size = new System.Drawing.Size(91, 22);
            this.lblTrianglePattern.Text = "Triangle Pattern";
            // 
            // frmBathroomTile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(932, 262);
            this.Controls.Add(this.tlsColorPatterns);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmBathroomTile";
            this.Text = "The Bathroom Tile Company";
            this.Load += new System.EventHandler(this.frmBathroomTile_Load);
            this.tlsColorPatterns.ResumeLayout(false);
            this.tlsColorPatterns.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tlsColorPatterns;
        private System.Windows.Forms.ToolStripLabel lblTile;
        private System.Windows.Forms.ToolStripSeparator sepTile;
        private System.Windows.Forms.ToolStripButton btnRectanglePattern;
        private System.Windows.Forms.ToolStripLabel lblRectanglePattern;
        private System.Windows.Forms.ToolStripButton btnTriangleButton;
        private System.Windows.Forms.ToolStripLabel lblTrianglePattern;
        private System.Windows.Forms.ToolStripTextBox txbTile;
        private System.Windows.Forms.ToolStripSeparator sepColor;
        private System.Windows.Forms.ColorDialog cdbColor;
        private System.Windows.Forms.ToolStripComboBox cmbColor;
    }
}

