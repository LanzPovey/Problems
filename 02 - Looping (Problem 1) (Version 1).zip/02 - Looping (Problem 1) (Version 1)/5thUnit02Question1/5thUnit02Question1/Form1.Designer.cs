﻿namespace _5thUnit02Question1
{
    partial class frmMillionaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMillionaire));
            this.lblEnter = new System.Windows.Forms.Label();
            this.txbAccountBalance = new System.Windows.Forms.TextBox();
            this.btnYearsGap = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblYear = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblEnter
            // 
            this.lblEnter.AutoSize = true;
            this.lblEnter.Font = new System.Drawing.Font("Harlow Solid Italic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnter.ForeColor = System.Drawing.Color.Goldenrod;
            this.lblEnter.Location = new System.Drawing.Point(11, 9);
            this.lblEnter.Name = "lblEnter";
            this.lblEnter.Size = new System.Drawing.Size(291, 24);
            this.lblEnter.TabIndex = 0;
            this.lblEnter.Text = "Enter you account balance below:";
            // 
            // txbAccountBalance
            // 
            this.txbAccountBalance.BackColor = System.Drawing.Color.LimeGreen;
            this.txbAccountBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbAccountBalance.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbAccountBalance.Location = new System.Drawing.Point(84, 36);
            this.txbAccountBalance.Name = "txbAccountBalance";
            this.txbAccountBalance.Size = new System.Drawing.Size(142, 24);
            this.txbAccountBalance.TabIndex = 1;
            // 
            // btnYearsGap
            // 
            this.btnYearsGap.BackColor = System.Drawing.Color.Lime;
            this.btnYearsGap.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYearsGap.ForeColor = System.Drawing.Color.Green;
            this.btnYearsGap.Location = new System.Drawing.Point(25, 66);
            this.btnYearsGap.Name = "btnYearsGap";
            this.btnYearsGap.Size = new System.Drawing.Size(263, 35);
            this.btnYearsGap.TabIndex = 2;
            this.btnYearsGap.Text = "Years to be a Millionaire";
            this.btnYearsGap.UseVisualStyleBackColor = false;
            this.btnYearsGap.Click += new System.EventHandler(this.btnYearsGap_Click_1);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.GreenYellow;
            this.btnReset.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnReset.Location = new System.Drawing.Point(38, 110);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(98, 36);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.GreenYellow;
            this.btnExit.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnExit.Location = new System.Drawing.Point(177, 110);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(98, 36);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // lblYear
            // 
            this.lblYear.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.ForeColor = System.Drawing.Color.Green;
            this.lblYear.Location = new System.Drawing.Point(13, 158);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(289, 45);
            this.lblYear.TabIndex = 5;
            // 
            // frmMillionaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(314, 213);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnYearsGap);
            this.Controls.Add(this.txbAccountBalance);
            this.Controls.Add(this.lblEnter);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMillionaire";
            this.Text = "Who wants to be a MILLIONAIRE?!";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEnter;
        private System.Windows.Forms.TextBox txbAccountBalance;
        private System.Windows.Forms.Button btnYearsGap;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblYear;
    }
}

