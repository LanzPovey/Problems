﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace _5thUnit04Example2
{
    public partial class frmExample2 : Form
    {
        const int SPACER = 5;
        public frmExample2()
        {
            InitializeComponent();
        }
        private void frmExample2_Load_1(object sender, EventArgs e)
        {
            // IF you ever lose your Intellisense, then do Ctrl + Spacebar.
            this.BackColor = Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            // It's putting NO / FORM BORDER STYLE / for this FORM / on WINDOWS / for this SYSTEM.

            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            // However, this doesn't work so it's removed.

            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            int width = frmExample2.ActiveForm.Width;
            // Since the screen is full screened, it shows how much pixels wide the screen is.

            // MessageBox.Show("Width = " + width);
            // Use this line of code to be able to see that (If you want to)

            int height = frmExample2.ActiveForm.Height;
            // This works the same as thw width variable, except with the height.
            // Now, it will be much easier to geometrically plot graphic objects on the screen.

            // btnExit.Location.Y;
            // Instead of them making this line of code, they made it simpilar by using the code under this line.
            btnExit.Top = SPACER;
            // Now, it goes down by 5 Y coordinates, since the SPACER variable is 5.
            // btnExit.Left = width - btnExit.Width;
            // Right now, it's 5 pixels lower than then top of the screen, but not with the right.
            // So, we'll add the line of code under this line to fix that.
            btnExit.Left = width - btnExit.Width - SPACER;

            btnRun.Top = btnExit.Top + btnExit.Height + SPACER;
            btnRun.Left = width - btnRun.Width - SPACER;
            // This then positions the Run button at the top left corner.

            // nudSize.Top = SPACER + btnExit.Height;
            // nudSize.Left = width - nudSize.Width - SPACER;
            // However, the Numeric Up Down is right underneat hthe X button, so let's give that some space too.
            nudSize.Top = btnRun.Top + btnRun.Height + SPACER;
            nudSize.Left = width - nudSize.Width - SPACER;

            nudSize.Minimum = SPACER;
            nudSize.Maximum = height - SPACER * 2;
            // This code makes it so that the Numeric Up Down can't go under 5 and can't go over 1040.
            // Since the screen resolution is 10, it subtracts the screen resolution width of 1850 - 10.
        }
        private void btnRun_Click(object sender, EventArgs e)
        {
            cdbColor.ShowDialog();
            // This is the third line of code that uses this parenthesis.
            // This is similar to the math operation f(x), which is a FUNCTION.
            // Since a function is a task, this is what the task is.
            // That means that this code is already programmed into the code.
            Color color = cdbColor.Color;
            // This line of code is essentially telling the computetr to remeber the color you chose.
            Graphics surface = this.CreateGraphics();
            // The "this" means that it's getting it from THIS form.
            surface.Clear(Color.Black);
            // Then, the surface is wiped and changed to the color black.
            Pen pen = new Pen(Color.White, 1);
            // The 1 signifies how big the pen is.
            Brush brush = new SolidBrush(color);
            // The word "color" is lowercase because it's reffering to the variable named "color" that was chosen by the user in the Color Dialogue Box.
            
            int size = (int)nudSize.Value;
            // Throwback to the variables unit, this is CASTING the "nudSize.Value"
            int move = size + SPACER;
            int maxY = frmExample2.ActiveForm.Height - size - SPACER;
            // You can't use the variable called "height" because that's not a Global Variable.
            // So instead, you'll need to get the height from the maximum height of the form.
            int maxX = frmExample2.ActiveForm.Width - size - SPACER;

            // There's actually a way to automatically put together the "for" loop.
            // To do so, type "for" then click tab TWICE.
            // You could do it manually, but this is much quicker with Intellisense.
            // However, you'll still need to change some stuff on that.
            // The below paragraph is what the default looks like when it's spawned in by Intellisense.

            //for (int i = 0; i < length; i++)
            //{
            //    
            //}

            for (int y = SPACER; y <= maxY; y += move)
            {
                for (int x = SPACER; x <= maxX; x += move)
                {
                    surface.FillEllipse(brush, x, y, size, size);
                    surface.DrawEllipse(pen, x, y, size, size);
                }
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

