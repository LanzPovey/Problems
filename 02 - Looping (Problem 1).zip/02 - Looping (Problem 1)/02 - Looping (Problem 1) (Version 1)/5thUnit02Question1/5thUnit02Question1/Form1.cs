﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5thUnit02Question1
{
    public partial class frmMillionaire : Form
    {
        public frmMillionaire()
        {
            InitializeComponent();
        }
        private void btnYearsGap_Click(object sender, EventArgs e)
        {
            double balance = Convert.ToInt32(txbAccountBalance.Text);
            double year = 0;
            const double INTEREST = 0.07;
            // This If Statement and Else If Statement needs to be at the top of this code, since if they aren't, then the double balance variable will have an error as a result of trying to convert a non string into a string.
            if (txbAccountBalance.Text == "") MessageBox.Show("Please type something into the textbox.");
            else if (balance >= 1000000) MessageBox.Show("WOAH! You're already a millionaire!");
            else if (balance <= 0) MessageBox.Show("You will NEVER be a millionaire!");
            else if (balance < 1000000)
            {
                while (balance < 1000000)
                {
                    balance += (balance * INTEREST);
                    year += 1;
                }
                lblYear.Text = "In " + Convert.ToString(year) + " you will be a MILLIONAIRE!";
            }
            else MessageBox.Show("Please type a proper number value into the textbox.");

            // The INTEREST variable doesn't need to be Global, since it's only being used in this code.

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            if (txbAccountBalance.Text != "")
            {
                txbAccountBalance.Text = "";
            }
            if (lblYear.Text != "")
            {
                lblYear.Text = "";
            }
        }

        private void btnYearsGap_Click_1(object sender, EventArgs e)
        {

        }
    }
}

