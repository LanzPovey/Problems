﻿//NAME: Lanz Povey
//DATE: June 7th 2016
//TEACHER: Mr. Wachs
//ASSIGNEMENT: Computer Science 20S, Unit 5: Looping. Question 3.
//PURPOSE: This program is used to generate shapes together into a pattern of either a user-inputted color or random colors for a the Bathroom Tile Company.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace _5thUnit05Question1
{
    public partial class frmBathroomTile : Form
    {
        // All of the explanations are on the Rectangle Button, except for a few differences between the two buttons.
        const int SPACER = 5, MIN_COLOR = 0, MAX_COLOR = 255;
        int red = 255, green = 255, blue = 255;
        Brush brush;
        Graphics surface;
        Pen pen;
        Random random;
        Color color;
        public frmBathroomTile()
        {
            InitializeComponent();
        }
        private void btnTriangleButton_Click(object sender, EventArgs e)
        {
            surface = this.CreateGraphics();
            random = new Random();
            if (txbTile.Text == "") MessageBox.Show("Please enter fill in the textbox for 'Set Tile Size' with a number value (Like 5 or 8)");
            else
            {
                if (cmbColor.Text == "Choose a Color")
                {
                    cdbColor.ShowDialog();
                    color = cdbColor.Color;
                }
                surface.Clear(Color.Aquamarine);
                int size = Convert.ToInt32(txbTile.Text), move = size + SPACER, maxX = frmBathroomTile.ActiveForm.Width - size - SPACER;
                int maxY = frmBathroomTile.ActiveForm.Height - size - SPACER;
                // The For Loops here have to be reversed, since x can't use y if y isn't create, so y needs to be created first.
                for (int y = SPACER; y <= maxY; y += move)
                { 
                    for (int x = SPACER; x <= y; x += move)
                    { // The Rectangle Button: {x <= MaxX} The Triangle Button: {x <= y}
                        if (cmbColor.Text == "Random Colors")
                        {
                            red = random.Next(MIN_COLOR, MAX_COLOR);
                            green = random.Next(MIN_COLOR, MAX_COLOR);
                            blue = random.Next(MIN_COLOR, MAX_COLOR);
                            color = Color.FromArgb(red, green, blue);
                        }
                        brush = new SolidBrush(color);
                        pen = new Pen(Color.White, 1);
                        surface.DrawEllipse(pen, x, y, size, size);
                        surface.FillEllipse(brush, x, y, size, size);
                    }
                }
            }
        }
        private void btnRectanglePattern_Click(object sender, EventArgs e)
        {
            // Theses objects don't have to have the green capitalized name infront of them (Like Graphics surface), since that's already stated at the Global Variables Spot.
            surface = this.CreateGraphics();
            random = new Random();
            if (txbTile.Text == "") MessageBox.Show("Please enter fill in the textbox for 'Set Tile Size' with a number value (Like 5 or 8)");
            else
            {
                if (cmbColor.Text == "Choose a Color")
                {
                    cdbColor.ShowDialog();
                    color = cdbColor.Color;
                }
                    surface.Clear(Color.Aquamarine);
                    int size = Convert.ToInt32(txbTile.Text), move = size + SPACER, maxX = frmBathroomTile.ActiveForm.Width - size - SPACER;
                    int maxY = frmBathroomTile.ActiveForm.Height - size - SPACER;
                    // I had to make this it's own integer, since if I added all the Integers together on one line, it would of become too much of a hassle to read.
                    for (int x = SPACER; x <= maxX; x += move)
                    {
                        for (int y = SPACER; y <= maxY; y += move)
                        {
                            if (cmbColor.Text == "Random Colors")
                            {
                                red = random.Next(MIN_COLOR, MAX_COLOR);
                                green = random.Next(MIN_COLOR, MAX_COLOR);
                                blue = random.Next(MIN_COLOR, MAX_COLOR);
                                color = Color.FromArgb(red, green, blue);
                            }
                            // These have to go inside of here so that a new pen and color is created for each tile, NOT each group of the tile.
                            brush = new SolidBrush(color);
                            pen = new Pen(Color.White, 1);
                            surface.DrawEllipse(pen, x, y, size, size);
                            surface.FillEllipse(brush, x, y, size, size);
                        }
                     }
            }
        }
        private void frmBathroomTile_Load(object sender, EventArgs e)
        {
            // The Global items (Like brush, graphics, etc.) don't have to go here, only at the Global Variable Spot.
            cmbColor.Items.Add("Random Colors");
            cmbColor.Items.Add("Choose a Color");
        }
    }
}